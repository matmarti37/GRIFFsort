#ifndef SORT_H
#define SORT_H

#include <time.h>

#include "sort_and_assemble_list.h"
#include "map.h"

FILE* out;

int analyze_fragment(Grif_event*, short*){return -1;};
#endif
