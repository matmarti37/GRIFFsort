#ifndef SORT_H
#define SORT_H



#include "sort_and_assemble_list.h"

short lt[2048];

int low,high;

#endif
