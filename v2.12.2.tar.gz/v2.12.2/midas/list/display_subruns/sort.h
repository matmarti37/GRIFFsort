#ifndef SORT_H
#define SORT_H



#include "sort_and_assemble_list.h"

int analyze_fragment(Grif_event*, short*){return -1;};
#endif
