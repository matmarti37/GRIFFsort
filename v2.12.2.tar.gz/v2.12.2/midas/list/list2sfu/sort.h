#ifndef SORT_H
#define SORT_H

#include "SFU-encoder.h"
#include "sort_and_assemble_list.h"
#include "map.h"


#define DB 100
#define DS  50



int analyze_list(int,int,node*){return -1;};
int analyze_fragment(Grif_event*, short*){return -1;};

#endif
