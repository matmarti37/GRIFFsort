#ifndef SORT_H
#define SORT_H

#include "SFU-common.h"
#include "SFU-format.h"
#include "SFU-decoder.h"

int pos,col,sup;
int  hist[NPOSTIGR][NCOL][NSUP][S32K];
int divider;
#endif
