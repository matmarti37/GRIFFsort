#ifndef __SFU_ENCODER_H
#define __SFU_ENCODER_H

#include "SFU-common.h"
#include "SFU-format.h"

int encode(raw_event*,FILE*, int*);
#endif
